<?php
// Heading
$_['heading_title']         = '<b style="color: #eb5202;"><i><i class="r fa fa-user"></i> DIVA Quick Login</i></b>';
$_['page_title']            = 'DIVA Quick Login';

// Text
$_['text_extension']        = 'Extensions';
$_['text_edit']             = 'Edit DIVA Quick Login Module';
$_['text_success']          = 'Success: You have modified module!';

// Entry
$_['entry_status']          = 'Status';
$_['entry_redirect_status'] = 'Redirect to Account';

//Error
$_['error_permission']      = 'Warning: You do not have permission to modify this module!';