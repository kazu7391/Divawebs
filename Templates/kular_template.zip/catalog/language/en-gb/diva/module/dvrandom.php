<?php
$_['title']     = "Random Products";

// Text
$_['text_tax']  = 'Ex Tax:';
