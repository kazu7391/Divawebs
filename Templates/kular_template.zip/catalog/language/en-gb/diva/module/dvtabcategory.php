<?php
$_['title']     = "Product Categories";

// Text
$_['text_tax']  = 'Ex Tax:';
$_['text_see_more']  = '+ See more';
$_['text_empty']        = 'There are no products in this category.';