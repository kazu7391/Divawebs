<?php
$_['title']     = "Trending items";

// Text
$_['text_tax']  = 'Ex Tax:';
