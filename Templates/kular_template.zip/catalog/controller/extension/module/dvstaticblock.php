<?php
class ControllerExtensionModuleDvstaticblock extends Controller
{
    public function index($setting) {
        $data['module_id'] = $setting['module_id'];

        $store_id = $this->config->get('config_store_id');

        if(isset($this->config->get('module_dvcontrolpanel_extension_custom')[$store_id])) {
            $module_custom = (int) $this->config->get('module_dvcontrolpanel_extension_custom')[$store_id];
        } else {
            $module_custom = 0;
        }

        if(isset($this->session->data['user_token']) && $module_custom) {
            $data['user_token'] = $this->session->data['user_token'];
        } else {
            $data['user_token'] = false;
        }
		
		if (isset($setting['module_description'][$this->config->get('config_language_id')])) {
            if(isset($setting['show_title'])) {
                $data['show_title'] = (int) $setting['show_title'];
            } else {
                $data['show_title'] = 0;
            }
            $data['title'] = html_entity_decode($setting['module_description'][$this->config->get('config_language_id')]['title'], ENT_QUOTES, 'UTF-8');
            $data['block_content'] = html_entity_decode($setting['module_description'][$this->config->get('config_language_id')]['description'], ENT_QUOTES, 'UTF-8');

            return $this->load->view('diva/module/dvstaticblock', $data);
        }
    }
}