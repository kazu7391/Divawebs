<?php
// Text
$_['text_empty']          = 'No posts';
$_['text_heading_title']  = 'Latest Blogs';
$_['text_blog']           = 'Blog';
$_['text_search']         = 'Search';
$_['button_show']         = 'Show more';
