<?php
$_['title']     = "Featured";

// Text
$_['text_tax']  = 'Ex Tax:';
$_['text_module']  = 'Add our featured products to your weekly lineup';
