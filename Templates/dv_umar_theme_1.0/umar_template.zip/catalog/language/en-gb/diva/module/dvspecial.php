<?php
$_['title']     = "Deal of the weeks";

// Text
$_['text_tax']  = 'Ex Tax:';
$_['text_availabe']  = "Availabe: ";
$_['text_sold']  = "Sold: ";
$_['text_shopnow']  = "shop now";
