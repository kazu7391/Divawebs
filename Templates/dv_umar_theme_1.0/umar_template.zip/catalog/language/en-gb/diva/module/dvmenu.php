<?php
$_['text_vertical_bar'] = 'Categories';
$_['text_mobile_bar'] = 'All Categories';
$_['text_more_item'] = 'More Items';
$_['text_close_item'] = 'Close Items';