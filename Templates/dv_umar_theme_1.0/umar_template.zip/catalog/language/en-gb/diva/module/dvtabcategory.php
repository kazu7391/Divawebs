<?php
$_['title']     = "Our Product";

// Text
$_['text_tax']  = 'Ex Tax:';
$_['text_see_more']  = '+ See more';
$_['text_empty']        = 'There are no products in this category.';
$_['text_module']        = 'Add our new arrivals to your weekly lineup';