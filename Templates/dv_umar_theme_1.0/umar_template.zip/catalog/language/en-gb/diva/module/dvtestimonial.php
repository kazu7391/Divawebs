<?php
$_['title']  = 'What customers say';
$_['text_module']  = 'Customer reviews about us';
$_['text_empty']     = 'There is no testimonial';