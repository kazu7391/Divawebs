<?php
// Text
$_['text_search']       = 'Search your products...';
$_['text_category']     = 'All Categories';
$_['text_empty']        = 'There are no products to list in this category.';
// Button
$_['button_search']       = 'Search';