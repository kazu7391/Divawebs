<?php
// Text
$_['text_empty']          = 'No posts';
$_['text_heading_title']  = 'Latest Blogs';
$_['text_module']  = 'Add our new arrivals to your weekly lineup';
$_['text_blog']           = 'Blog';
$_['text_search']         = 'Search';
$_['button_show']         = 'Show more';
