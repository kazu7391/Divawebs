<?php
$_['title']     = "Bestseller";

// Text
$_['text_tax']  = 'Ex Tax:';
