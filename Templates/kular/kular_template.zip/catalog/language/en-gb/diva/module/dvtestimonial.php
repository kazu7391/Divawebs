<?php
$_['title']  = 'What customers say';
$_['text_empty']     = 'There is no testimonial';