<?php
$_['title'] = "Popular Categories";
$_['text_product_empty'] = "There are no products to list in this category.";
$_['text_shopnow'] = "shop now";