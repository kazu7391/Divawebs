<?php
$_['title']             = "Product Tabs";

// Text
$_['text_tax']          = 'Ex Tax:';
$_['text_bestseller']   = 'Bestseller';
$_['text_mostviewed']   = 'Most Viewed';
$_['text_random']       = 'Random';
$_['text_special']      = 'Special';
$_['text_latest']       = 'Latest';
$_['text_empty']        = 'No products';