<?php
$_['title']     = "Featured";

// Text
$_['text_tax']  = 'Ex Tax:';
